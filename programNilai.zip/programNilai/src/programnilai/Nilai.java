/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programnilai;

/**
 *
 * @author Adi Arput
 */
public class Nilai {
    public int getnilaiPengetahuan (int pengetahuan){
        return pengetahuan;
    }
    public int getnilaiKeterampilan (int keterampilan){
        return keterampilan;
    }
}